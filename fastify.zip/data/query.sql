INSERT INTO todos (name,status,date) values("chier",0,"1015")
